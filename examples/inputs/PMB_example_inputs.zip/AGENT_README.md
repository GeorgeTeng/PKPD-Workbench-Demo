# PMB data package (proposal version 3.0)

## Files in this package
- `PMB_project_proposal.docx`: task definition and operative rules.
- `PMB_source_tables_by_species.xlsx`: animal and in-vitro data. Sheets: Mouse, Rat, Rabbit, Horse, In_vitro_MIC. The Horse sheet is a held-out translation check: do not use it for fitting, selection or scaling; open it only after the mouse/rat/rabbit scaling is frozen (task 3).
- `benchmark_reference.json`: published model-derived results. Keep hidden until the final benchmark.

## How to read the workbook
Each sheet holds separate source-shaped blocks: title, source line (S number, DOI, table or figure), notes, then the original header and values. Split and qualify the blocks yourself. Preserve missing symbols, units, SD versus SEM, dose basis, analyte, route, experimental unit and study boundaries. Row counts are not animal counts. Digitized means and scatter markers are not individual raw observations.

## Known gaps
- No verified complete regimen-to-CFU file for the 29 S02 fractionation regimens; do not fill responses by model inversion.
- No cross-panel join between S01 digitized index panels.
- Rabbit evidence is mean-only; no further public rabbit PMB concentration data were found.
- Protein binding sources conflict (mouse about 91% vs 97–99% bound; rat 80% vs 92–99%). Keep all; carry fu as a sensitivity parameter.
- Horse: the 2006 single/repeated-dose curves (S31 Figures 3–4) were not accessible; only printed values are included. Digitized horse markers carry overlap flags.
- Not yet transcribed (source pages not accessible): S02 full tables, Manchandani 2017 rat SC dose-ranging values, S27 per-time CFU (supplement SuF1).
- The ten-bin MIC distribution sums to 99.57% and is kept without renormalization.

## Held-out validation data (not in this package)
- `PMB_human_validation_tables.xlsx`: 40-patient PK dataset and human reference tables, released at task 5.
