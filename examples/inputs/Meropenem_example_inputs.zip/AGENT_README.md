# Meropenem data package (proposal version 1.0)

## Files in this package
- `Meropenem_project_proposal.docx`: task definition and operative rules.
- `Meropenem_source_tables_by_species.xlsx`: animal and in-vitro data. Sheets: Cross_species, Mouse, Rat, Rabbit, Dog, Monkey, In_vitro_MIC. Cross_species holds tables in which one source covers several species; split them by species yourself.

## How to read the workbook
Each sheet holds separate source-shaped blocks: title, source line (S number, DOI, table or figure), notes, then the original header and values. Split and qualify the blocks yourself. Preserve missing symbols, units, SD versus SE, dose basis, analyte, matrix, route, experimental unit and study boundaries. Row counts are not animal counts. Digitized means and published fitted parameters are not individual raw observations. Values are copied as printed, including footnote markers and printed inconsistencies; block notes flag the known ones.

## Known gaps
- No regimen-level CFU tables. S04 gives fitted PD parameters only, S05 tests one humanized regimen per strain (CFU changes are in a figure), S06 targets are ELF-based, and S08 reports survival.
- Only S01 Figure 1 is digitized. Concentration figures in S02 (rat 14C), S03 (dog and monkey), S05, S06 and S09 are not transcribed.
- S08 measured concentrations are in a supplementary table that was not accessible. S10 (dog IV and SC) is abstract only.
- Protein binding sources conflict within species: mouse 33.8% (S01) vs about 10% (S07) vs 20.6-24.4% (S03); dog 7.5% (S01) vs 0.2-0.9% (S03) vs 11.87% (S10); rabbit 21.2% (S01) vs 9.7-13.8% (S11); monkey 7.9% (S01, rhesus) vs 0.6-4.0% (S03, cynomolgus). Keep all; carry fu as a sensitivity parameter.
- Some regimen details are not reported by the sources; block notes say "not stated" where this applies: S04 PK route, sampling times and per-injection doses; S05 PK sampling times; S06 individual PK doses and mice per efficacy cohort; S09 total treatment duration and rabbits per dose group. S08 dosed for 12 h only and then followed survival for 7 days.
- Mouse half-life differs widely between sources (S01 4.5 min, S04 0.09-0.32 h, S07 text).
- Guinea pig data come from one source (S01) only.
- Not included because full text was not accessible: the Harrison 1989 multi-species disposition study, dog constant-rate infusion and hemodialysis studies, and burn-injured rat studies.

## Held-out validation data (not in this package)
- `Meropenem_human_reference_tables.xlsx`: label PK statements and neonatal table, a healthy-volunteer study, EUCAST summary PK, and the human rows removed from S01, S03, S05, S06 and S11; released at task 5.
