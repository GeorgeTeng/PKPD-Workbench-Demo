# Voriconazole data package (proposal version 1.0)

## Files in this package
- `Voriconazole_project_proposal.docx`: task definition and operative rules.
- `Voriconazole_source_tables_by_species.xlsx`: animal and in-vitro data. Sheets: Mouse, Rat, Cross_species_secondary, In_vitro_MIC. Mouse and Rat hold primary sources only. Cross_species_secondary holds one table reproduced in a thesis from Roffey et al. 2003; it is secondary and low confidence, and its column-to-species mapping is unverified.

## How to read the workbook
Each sheet holds separate source-shaped blocks: title, source line (S number, DOI, table or figure), notes, then the original header and values. Split and qualify the blocks yourself. Preserve missing symbols, units, SD versus SE, dose basis, route, treatment day, matrix, assay, experimental unit and study boundaries. Row counts are not animal counts. Digitized means, published fitted parameters and model-predicted AUCs are not individual raw observations. Values are copied as printed, including Portuguese decimal commas and printed inconsistencies; block notes flag the known ones.

## Known gaps
- The multi-species original (Roffey 2003) was not accessible. Rabbit, guinea pig and dog appear only in the secondary table; there is no primary PK for these species in the package.
- Only S03 Figure 2 is digitized; its 0 h markers overlap and were not digitized, and its plotted times differ from the sampling times in the methods. Concentration figures in S02, S04, S06, S07 and S08 are not transcribed.
- S03 and S04 sampled PK on day 2 of treatment, which is neither single-dose nor steady state.
- No regimen-level CFU table: S02 per-regimen kidney CFU values are in figures only; S03 and S04 report survival.
- Protein binding sources conflict: mouse 78% bound in serum (S02) vs 29.97% unbound in plasma (S03, 29.87% in its discussion) vs 67% (S01, secondary); rat 65% and 64% (S07) vs 66% (S01). Keep all; carry fu as a sensitivity parameter.
- Some regimen details are not reported by the sources; block notes say so where this applies: S02 route of efficacy dosing and an explicit treatment duration for the K-1 dose-fractionation study; S04 unit of the LD90 inocula; S05 mouse weight; S06 rat age and weight.
- S07 does not label which AUC in its sentence belongs to which matrix and group; the order is inferred.
- Not included because full text was not accessible: guinea pig CSF and brain study, dog repeated-dose study. Guinea pig efficacy studies without drug concentrations and non-target species were left out.

## Held-out validation data (not in this package)
- `Voriconazole_human_reference_tables.xlsx`: label Table 12 and PK statements, a healthy-volunteer IV-to-oral dose-escalation study (Purkins 2002), and the human-target column removed from S06 Table 1; released at task 5.
