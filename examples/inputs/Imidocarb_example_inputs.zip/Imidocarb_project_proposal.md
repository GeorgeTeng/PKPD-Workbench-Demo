# Imidocarb cattle PK data organization proposal

## Objective
Organize the supplied imidocarb cattle source workbook into a traceable Data handoff for later descriptive EDA and PK modeling. This run stops after source-preserving Data preparation and its recorded review gate.

## Authorized inputs
Use Imidocarb_cattle_source.xlsx as the supplied observational source. Use Imidocarb_source_notes.txt only as cited source context. The article's conclusions are historical statements, not validation by this workflow. Do not browse for or add external data.

## Data requirements
Register every supplied file and its hash. Identify the workbook tables, original headers, sampling times, animal IDs, formulation groups, measurement values, units when stated, and summary/formula columns. Preserve raw values, original cell coordinates, formulas, and missing or ambiguous metadata. Keep individual observations distinct from reported summaries. Do not infer a global subject identity from repeated IDs across groups or join tables without an explicit source binding.

## Allowed preparation and unresolved issues
Create source-bound labels, literal tables, a data dictionary, a cleaning record, a QC report and a handoff. Do not impute concentrations, reinterpret blanks as zero, recompute source formulas, average records, convert units, transpose or pool the groups. Any uncertain table structure, sampling identity, formula result or metadata binding must remain visible in the unresolved ledger for later review.

## Review and execution boundary
Retain Context and Data review checkpoints with output signatures. Automatic approval is authorized only for this technical demo. No EDA, parameter estimation, bioequivalence calculation, human translation or scientific release is authorized by this run. Missing modeling requirements remain deferred for subsequent human review rather than silently resolved.
